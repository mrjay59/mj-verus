#!/system/bin/sh
# executed when Magisk boots the module (service.d)
LOG=/data/adb/adbroot_enabler.log
echo "[adbroot] start $(date)" >> $LOG

# try append a shipped adbkey.pub in module/system/etc/adbkey.pub (optional)
MODPATH=/data/adb/modules/adbroot.enabler
if [ -f "$MODPATH/adbkey.pub" ]; then
  mkdir -p /data/misc/adb
  cat "$MODPATH/adbkey.pub" >> /data/misc/adb/adb_keys
  chown system:shell /data/misc/adb/adb_keys
  chmod 660 /data/misc/adb/adb_keys
  echo "[adbroot] appended adbkey from module" >> $LOG
fi

# try restart adbd by setprop
setprop service.adb.root 1 2>/dev/null || setprop persist.service.adb.root 1 2>/dev/null
stop adbd 2>/dev/null || true
start adbd 2>/dev/null || true

echo "[adbroot] done $(date)" >> $LOG
