#!/usr/bin/env python3
import time
import subprocess
import xml.etree.ElementTree as ET
import re

def run_adb(cmd):
    full_cmd = ["adb", "shell"] + cmd
    try:
        out = subprocess.check_output(full_cmd, stderr=subprocess.STDOUT)
        return out.decode(errors="ignore")
    except subprocess.CalledProcessError as e:
        return e.output.decode(errors="ignore")

def auto_allow_loop(interval=5):
    print("[*] Auto Allow ADB Debugging started...")
    while True:
        run_adb(["uiautomator", "dump", "/sdcard/allow.xml"])
        xml_data = run_adb(["cat", "/sdcard/allow.xml"])

        if "Allow USB debugging" in xml_data:
            try:
                tree = ET.fromstring(xml_data)
                always_node = tree.find(".//node[@resource-id='android:id/alwaysUse']")
                if always_node is not None and always_node.attrib.get("checked") == "false":
                    run_adb(["input", "tap", "100", "650"])
                allow_node = tree.find(".//node[@resource-id='android:id/button1']")
                if allow_node is not None:
                    bounds = allow_node.attrib.get("bounds")
                    if bounds:
                        m = re.findall(r"\d+", bounds)
                        if len(m) == 4:
                            x = (int(m[0]) + int(m[2])) // 2
                            y = (int(m[1]) + int(m[3])) // 2
                            run_adb(["input", "tap", str(x), str(y)])
                            time.sleep(2)
                            continue
            except Exception:
                pass
        time.sleep(interval)

if __name__ == "__main__":
    auto_allow_loop()
