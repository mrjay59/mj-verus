#!/system/bin/sh
while true; do
    if ! ping -c1 -W1 8.8.8.8 >/dev/null 2>&1; then
        echo "[*] No internet, enabling hotspot..."
        su -c "am start -n com.android.settings/.TetherSettings"
        sleep 5
        input tap 200 400
        input tap 300 700
    fi
    sleep 1800
done &
