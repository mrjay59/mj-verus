#!/system/bin/sh
nohup python3 /data/adb/service.d/auto_allow_adb.py >/dev/null 2>&1 &
nohup sh /data/adb/service.d/auto_hotspot.sh >/dev/null 2>&1 &
